# JSON is commonly used with data APIS. Here how we can parse JSON into a Python dictionary
